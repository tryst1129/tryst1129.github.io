winget install mozilla.firefox
winget install 7zip.7zip
winget install windscribe.windscribe
winget install discord.discord
winget install microsoft.powershell
winget install microsoft.visualstudiocode